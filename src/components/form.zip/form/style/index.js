import 'm78/init';
import './index.scss';
