import 'm78/form/style';
import Form from './form';

export * from './type';
export * from './form';
export { useForm } from 'rc-field-form';
export * from 'rc-field-form/es/interface';
export { Form };
